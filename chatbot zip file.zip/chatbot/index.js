var express = require('express')
var ejs = require('ejs')


var app = express();

app.use(express.static('public'));
app.set('view engine', 'ejs');

app.listen(8080);

//localhost:8080
app.listen(8080, function(){
    console.log("Server running at http://localhost:8080");
});
app.get('/',function(req,res){

    res.render('pages/index');
   
    
});


    app.get('/about',function(req,res){
        res.render('pages/about')
})


    app.get('/contact',function(req,res){
        res.render('pages/contact')
})