
var sendBtn = document.getElementById('sendBtn');
var textbox = document.getElementById('textbox');
var chatContainer = document.getElementById('chatContainer');

var user = { message: "" };

var arrayOfPossibleMessage = [
  { message: "hi", response: "hello,how can i assit you" },
  { message: "how are you?", response: "I'm good" },
  { message: "what is your name?", response: "I'm a Chatbot!" },
  { message: "what are your business hours?", response: "Our business hours are 9 AM to 6 PM, Monday to Friday." },
  { message: "where is my order?", response: "Please provide your order number so I can check the status." },
  { message: "i want to place an order", response: "Sure! What product would you like to order?" },
  { message: "how can i contact support?", response: "You can reach our support team at support@example.com or call 123-456-7890." },
  { message: "do you offer refunds?", response: "Yes, we offer refunds within 30 days of purchase with a valid receipt." },
  { message: "what payment methods do you accept?", response: "We accept credit cards, PayPal, and bank transfers." },
  { message: "i want to cancel my order", response: "Please provide your order number to proceed with the cancellation." },
  { message: "what's up?", response: "Just a friendly bot at your service!"},
  { message: "what is your name?", response: "I'm a chatbot!"},
  { message: "good morning", response: "Good morning! How can I help?"},
  { message: "can you cry?", response: "No tears here, just code!"},
  { message: "can you smile?", response: "😊 Just like that!"},
  { message: "who invented the light bulb?", response: "Thomas Edison lit up the world—literally!" },
  { message: "can you dance?", response: "Only if binary breakdancing counts 🤖🕺" },
  { message: "how many letters in the alphabet?", response: "26 — and they're all very busy!" },
  { message: "what organ pumps blood?", response: "The heart — your hardworking muscle!" },
  { message: "what country has the most population?", response: "India — with over 1.4 billion people!" },
  { message: "what is the freezing point of water?", response: "0°C or 32°F!" },
  { message: "many teeth does an adult human have?", response: "32 — unless your wisdom teeth bailed!" },
  { message: "who is the first president of the USA?", response: "George Washington — the OG president!" },
  { message: "how many legs does a spider have?", response: "Eight — creepy and efficient!" },
  { message: "what is the largest land animal?", response: "The African elephant — big ears, bigger body!" },
  { message: "can you solve equations?", response: "Absolutely! Throw one at me." },
  { message: "what is the square root of 16?", response: "That's 4!" },
  { message: "is pi a rational number?", response: "Nope, it's irrational and goes on forever!" },
  { message: "can you do calculus?", response: "Yep, derivatives and integrals are my jam!" },
  { message: "what's the value of pi?", response: "Approximately 3.14159." },
  { message: "what is 10 factorial?", response: "That's 3,628,800!" },
  { message: "can you do algebra?", response: "For sure! X marks the spot." },
  { message: "what is 100 divided by 4?", response: "That would be 25." },
  { message: "do you like math?", response: "Of course! It's in my DNA—Digital Numeric Ability 😄" },
  { message: "what is 2 + 2?", response: "Easy! It's 4." },
  { message: "what is 5 x 6?", response: "That's 30!" },
  { message: "what is 15 - 7?", response: "The answer is 8." },
  { message: "what is 81 divided by 9?", response: "That’s 9." },
  { message: "what is the square root of 49?", response: "It's 7!" },
  { message: "what is 10 squared?", response: "That's 100." },
  { message: "what is 1000 minus 1?", response: "999 – just shy of a thousand." },
  { message: "can you solve equations?", response: "Absolutely! Throw one at me." },
  { message: "what is 3 + 4 x 2?", response: "Order matters! It's 11." },
  { message: "what is 10 divided by 0?", response: "Ah, that’s undefined!" },
  { message: "is 29 a prime number?", response: "Yes, it is!" },
  { message: "what's the value of pi?", response: "Approximately 3.14159." },
  { message: "what is e in math?", response: "It's Euler’s number, around 2.718." },
  { message: "what is 6 factorial?", response: "720! That's a lot of multiplying 😅" },
  { message: "what is 3 cubed?", response: "27! Small but mighty 💪" },
  { message: "what is 9 squared?", response: "81! Square it like a pro 😎" },
  { message: "what is 5 to the power of 2?", response: "25! Power moves only ⚡" },
  { message: "what is 0 factorial?", response: "It’s 1! Weird, right? 😄" },
  { message: "what is 4 cubed?", response: "64! Cube-tastic 🧊" },
  { message: "what is 10 squared?", response: "100! Double digits done right ✨" },
  { message: "what is 2 factorial?", response: "That’s 2! Short and sweet 😊" },
  { message: "what is 11 squared?", response: "121! Fancy number, huh? 😏" },
  { message: "what is 1 to any power?", response: "Still 1! Loyal little number 😇" },
  { message: "good afternoon", response: "very good afternoon" }
  
  
];
  
    
  

function sendMessage(userMessage) {
  var messageElement = document.createElement('div');
  messageElement.style.textAlign = "right";
  messageElement.style.margin = "10px";
  messageElement.innerHTML = "<span>You: </span>" + "<span>" + userMessage + "</span>";
  chatContainer.appendChild(messageElement);
}

function chatbotResponse(userMessage) {
  var chatbotmessage = "";

  if (userMessage.length > 5 || userMessage.toLowerCase() == "hi") {
    var result = arrayOfPossibleMessage.filter(val => val.message.includes(userMessage.toLowerCase()));
    if (result.length > 0) {
      chatbotmessage = result[0].response;
    } else {
      chatbotmessage = "please send another message";
    }
  } else {
    chatbotmessage = "please send different message";
  }

  var messageElement = document.createElement('div');
  messageElement.innerHTML = "<span>Chatbot:</span>" + "<span>" + chatbotmessage + "</span>";

  setTimeout(() => {
    messageElement.animate([{ easing: "ease-in", opacity: 0.4 }, { opacity: 1 }], { duration: 1000 });
    chatContainer.appendChild(messageElement);
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }, 1000);
}

// ✅ Moved this OUTSIDE the chatbotResponse function
sendBtn.addEventListener('click', function (e) {
  var userMessage = textbox.value;

  if (userMessage.trim() === "") {
    alert('please type in a message');
  } else {
    let userMessageText = userMessage.trim();
    textbox.value = "";
    sendMessage(userMessageText);
    chatbotResponse(userMessageText);
  }
});
